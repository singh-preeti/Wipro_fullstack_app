export class User {
    id: string | undefined;
    name: string | undefined;
    email: string | undefined;
}